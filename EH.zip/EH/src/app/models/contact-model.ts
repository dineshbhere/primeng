export class ContactList {
    constructor(
        public Id: any,
        public FirstName: any,
        public LastName: any,
        public Email: any,
        public PhoneNumber: any,
        public Status: any,
    ) { }
}
